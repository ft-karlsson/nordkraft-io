# Deploy en Webapp

!!! info "Kommer snart"
    Denne guide er under udarbejdelse.

## Quick start

```bash
# Node.js app
nordkraft deploy ghcr.io/username/myapp:v1 --port 3000

# Python Flask
nordkraft deploy ghcr.io/username/flask-app:v1 --port 5000

# Go app
nordkraft deploy ghcr.io/username/go-app:v1 --port 8080
```

Se [Din første container](../getting-started.md) for fuld tutorial.
